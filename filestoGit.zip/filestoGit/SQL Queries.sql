----- DEfect 1031 ----
select cc.ClaimNumber,* from cc_claim cc
join cc_activity act on act.ClaimID = cc.ID
join cc_document doc on doc.ClaimID = cc.ID
join cctl_documenttype docType on docType.ID = doc.Type
join cctl_wcb_documentsubtype docSubType on docSubType.ID = doc.SubType
where cc.Segment in (10016,10023) and docType.TYPECODE =3000  and docSubType.TYPECODE=3000 and doc.Author='Cheque Clearing Integration'
and act.Subject='New Mail' and act.Status=1 and act.CreateTime > '2019-06-05 00:00:00.0000000'


select cc.Claimnumber,act.Status from cc_claim cc
join cc_activity act on act.ClaimID = cc.ID
where cc.state =3 and  act.Subject='New Mail' and act.Status=1 

----- DEfect 1031 ----
select clm.State,act.CloseUserID,act.Status,act.UpdateTime,act.ID,act.Subject as actSubject,pat.Code,pat.Subject as patSubject from cc_activity act
join cc_activitypattern pat on pat.ID=act.ActivityPatternID
join cc_claim clm on act.ClaimID=clm.ID
where clm.ClaimNumber='6020336'

select act.AssignedUserID,pat.Code,clm.AssignedUserID,clm.AssignedGroupID,clm.PreviousGroupID,clm.PreviousUserID,cs.NAME as Segment,clm.WCB_isOpenForMedavie,clm.State,act.UpdateTime,act.Subject as actSubject 
from cc_activity act
join cc_activitypattern pat on pat.ID=act.ActivityPatternID
join cc_claim clm on act.ClaimID=clm.ID
join cctl_claimsegment cs on cs.ID=clm.Segment
where clm.ClaimNumber='6021772' order by  act.UpdateTime asc

select chk.UpdateTime,ts.NAME,chk.PublicID,chk.CheckNumber,clm.ClaimNumber from cc_check chk 
join cc_claim clm on clm.ID=chk.ClaimID
join cctl_transactionstatus ts on ts.ID=chk.Status
where chk.CheckNumber in ('5003610','5043645','5062266') 

update chk set chk.status= 2,chk.IssueDate = chk.ScheduledSendDate,chk.WCB_CheckClearanceDate=DATEADD(DD,1,chk.ScheduledSendDate),chk.UpdateTime=GETDATE()  from cc_check chk
where chk.publicid in ('cc:20111552','cc:20111551','cc:20111550','cc:20111550','cc:20111549','cc:20111548','cc:20111547','cc:20111546','cc:20111545','cc:20111544',
'cc:20111543','cc:20111542','cc:20111541','cc:20111491','cc:20111490','cc:20111140','cc:20111139')

select * from cc_claimcontactrole ccr 
join cc_claimcontact cc on cc.ID = ccr.ClaimContactID
join cc_claim clm on clm.ID = cc.ClaimID

where ClaimNumber='6013415'


select ccr.Retired as CCRRetired,cc.Retired  as CCRetired, ct.Retired as CTRetired, cc.ID as CCID, ct.ID as CTID,cr.NAME 
from cc_claimcontactrole ccr
join cc_claimcontact cc on cc.ID = ccr.ClaimContactID
join cc_claim clm on clm.ID = cc.ClaimID
join cc_contact ct on cc.ContactID = ct.ID
join cctl_contactrole cr on cr.ID = ccr.Role
where clm.ClaimNumber='6018819'
order by cc.CreateTime asc

select tll.CreateTime,tll.ID,tll.TransactionID,tll.LineCategory,tll.TransactionAmount,tll.currentLineCategory  from cc_transactionlineitem tll
join cc_transaction trans on tll.TransactionID=trans.ID
join cc_claim clm on trans.ClaimID = clm.ID
join cc_check chk on chk.ID = trans.CheckID
where chk.CheckNumber='5043737' order by tll.CreateTime asc


select  chk.CheckNumber,tll.TransactionAmount as TransaAmount,count(tll.TransactionAmount),lc.Name, count(lc.NAME),tll.TransactionID,count(tll.TransactionID) from cc_transactionlineitem tll
join cc_transaction trans on tll.TransactionID=trans.ID
join cc_claim clm on trans.ClaimID = clm.ID
join cc_check chk on chk.ID = trans.CheckID
join cctl_linecategory lc on tll.LineCategory = lc.ID
where clm.ClaimNumber='6018725'
group by tll.TransactionAmount,lc.Name,tll.TransactionID,chk.CheckNumber
having count(tll.TransactionAmount) > 1 

select act.Status, clm.LoadCommandID
from cc_activity act
join cc_claim clm on act.ClaimID=clm.ID
where clm.ClaimNumber='6028012'

update act set act.Status='3' from cc_activity act
join cc_activitypattern pat on pat.ID=act.ActivityPatternID
join cc_claim clm on act.ClaimID=clm.ID
join cctl_claimsegment cs on cs.ID=clm.Segment
where clm.ClaimNumber='6028012' 

select ast.NAME,act.Subject,clm.ClaimNumber,act.AssignedGroupID,clm.wcb_NatureofInjury 
from cc_activity act
join cc_activitypattern pat on pat.ID=act.ActivityPatternID
join cc_claim clm on act.ClaimID=clm.ID
join cctl_claimsegment cs on cs.ID=clm.Segment
join cctl_activitystatus ast on ast.ID = act.Status
where pat.Code='assignment_review' and  clm.wcb_NotificationForm='10001'  and act.Status='1' and clm.wcb_NatureofInjury='10007'

---------------------

select ast.NAME as ActivityState,act.Subject,div.NAME as NatureOfInjury,act.CreateTime,clm.ClaimNumber, cs.NAME as Segment,act.UpdateTime
from cc_activity act
join cc_activitypattern pat on pat.ID=act.ActivityPatternID
join cc_claim clm on act.ClaimID=clm.ID
join cctl_claimsegment cs on cs.ID=clm.Segment
join cc_group grp on grp.ID=act.AssignedGroupID
join cctl_activitystatus ast on ast.ID = act.Status
join cctl_claimstate st on st.ID = clm.State
join cctl_wcb_natreofinjry_division div on div.ID =  clm.wcb_NatureofInjury
where pat.Code='assignment_review' and  clm.wcb_NotificationForm='10001'  and act.Status='1'
-------------------------------






select * from ccx_wcb_invoice wi where wi.InvoiceNumber='2019082080'



select ex.ExpenseStatus,ex.InvoiceNumber,ex.InvoiceTreatmentType,ex.AppointmentDate from ccx_expense ex 
join cc_claim clm on clm.ID = ex.ClaimID
--join cctl_wcb_expensestatus es on es.ID = ex.ExpenseStatus
where clm.ClaimNumber='2256922'
--where ex.InvoiceNumber='2019082080'
--    var invoices = claim.WCB_Invoice?.where(\elt -> elt.Action == WCB_InvoiceStatus.TC_PENDING and
     --   ((elt.FromPortal and elt.Status == WCB_InvoiceStatus.TC_FINAL) or(elt.FromPortal == false and elt.Status == null))

select inv.Action,inv.Status,inv.ClaimID,* from ccx_wcb_invoice inv
where inv.ClaimID='1125454'

select ctt.NAME,* from ab_abcontact cnt
left join ab_address adr on adr.id = cnt.primaryaddressid
left join abtl_addresstype adt on adt.id = adr.AddressType
left join ab_contacttag tag on tag.ContactID = cnt.id
join ab_abcontacttag  abct on abct.ABContactID = cnt.ID
left join abtl_contacttagtype ctt on ctt.id = abct.Type
where cnt.FirstName='doctor'
order by cnt.UpdateTime desc

select clm.ClaimNumber,cr.NAME,cc.ID,ct.ID,cc.Retired as ClaimContactRetired,ct.RETIRED as ContactRetired 
from cc_claimcontactrole ccr
join cc_claimcontact cc on cc.ID = ccr.ClaimContactID
join cc_claim clm on clm.ID = cc.ClaimID
join cc_contact ct on cc.ContactID = ct.ID
join cctl_contactrole cr on cr.ID = ccr.Role
where ccr.Role='26' and ccr.Retired!='0' 


    var unlinkedContacts = Query.make(ClaimContactRole)
        .compare(ClaimContactRole#Role, Relop.Equals, ContactRole.TC_CLAIMANT)
        .join("ClaimContact")
        .join("Contact")
        .compare(Contact#AddressBookUID, Relop.Equals, null)
        .select().toList()
		
		var agentContacts = Query.make(Claim)
        .join(ClaimContact, "Claim")
        .join(ClaimContactRole, "ClaimContact")
        .compare(ClaimContactRole#Role, Relop.Equals, ContactRole.TC_AGENT).select().toList()
		
		
		    var claims = Query.make(Claim)
        .compare(Claim#State, Relop.Equals, ClaimState.TC_CLOSED)
        .join(ClaimContact, "Claim")
        .join("Contact")
        .compare(Contact#AddressBookUID, Relop.Equals, /*claimants addressbookid*/'ab:659969').select().toList()

select usr.UpdateTime,crd.UserName,* from cc_user usr
join cc_credential crd on crd.ID = usr.CredentialID
order by usr.UpdateTime desc

update crd set crd.UserName='su' from cc_user usr
join cc_credential crd on crd.ID = usr.CredentialID
where usr.PublicID='default_data:1'